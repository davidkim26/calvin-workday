// Add event listener to the chatbot input field
document.getElementById('input-message').addEventListener('keydown', function (event) {
  if (event.keyCode == 13) {
    event.preventDefault();
    const inputMessage = document.getElementById('input-message');
    const messagesContainer = document.getElementById('messages-container');
    const message = document.createElement('div');
    message.classList.add('message');
    message.textContent = inputMessage.value;
    messagesContainer.appendChild(message);
    inputMessage.value = '';
    // Add code to send a message to the chatbot here...
  }
});

